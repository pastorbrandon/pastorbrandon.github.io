# Horadric Companion (Starter)
Offline-first PWA scaffold.

## Deploy (GitHub Pages)
1) Create public repo.
2) Upload this folder (or push via git).
3) Settings → Pages → Deploy from branch (main/root).
4) Open URL → Add to Home Screen on iPhone.
